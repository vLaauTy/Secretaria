package com.Secretaria.Secretaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
